<?php
class Evedence_model extends CI_Model{
	
public function show(){
	
$data=$this->db->get('tbl_evedence');
return $data;	
	
}	
public function insert($data){	
$this->db->insert('tbl_evedence',$data);	
}	
public function delete_user($user){	
$this->db->where('id',$user);	
$this->db->delete('tbl_evedence');	
}	
			
	
	
}
?>