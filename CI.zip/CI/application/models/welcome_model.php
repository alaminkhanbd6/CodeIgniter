<?php

class Welcome_Model extends CI_Model {
    
    public function select_all_published_category(){
        $this->db->select('*');
        $this->db->from('tbl_category');
        $this->db->where('category_status',1);
        $query_result=$this->db->get();
        $result=$query_result->result();
        return $result;
    }
    
    public function select_all_published_blog()
    {
        $this->db->select('*');
        $this->db->from('tbl_blog');
        $this->db->where('category_status',1);
        $query_result=$this->db->get();
        $result=$query_result->result();
        return $result;  
    }
            
    
    public function select_blog_info_by_id($blog_id)
    {
        $this->db->select('*');
        $this->db->from('tbl_blog');
        $this->db->where('blog_id',$blog_id);
        $query_result=$this->db->get();
        $result=$query_result->row();
        return $result; 
    }
    public function select_blog_by_category_id($category_id)
    {
        $this->db->select('*');
        $this->db->from('tbl_blog');
        $this->db->where('category_id',$category_id);
        $query_result=$this->db->get();
        $result=$query_result->result();
        return $result;  
    }
    public function save_user_info($data)
    {
        $this->db->insert('tbl_user',$data);
    }
    public function user_login_check_info($email_address,$password)
    {
        $this->db->select('*');
        $this->db->from('tbl_user');
        $this->db->where('email_address',$email_address);
        $this->db->where('password', md5($password));
        $query_result=$this->db->get();
        $result=$query_result->row();
        return $result;  
    }
    
    public function select_recent_blog()
    {
     $sql="SELECT * FROM `tbl_blog` ORDER BY blog_id DESC LIMIT 0,3" ;  
     $query_result=$this->db->query($sql);
     $result=$query_result->result();
     return $result;
     
    }
}
