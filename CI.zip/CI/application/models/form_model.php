<?php
class Form_model extends CI_Model{
	
public function insert($data){
	$this->db->insert('tbl_form',$data);
}	
	
	
	
	
}

?>