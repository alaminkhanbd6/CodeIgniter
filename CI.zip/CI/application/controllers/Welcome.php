<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{       $data=array();
                $data['all_published_category']=$this->welcome_model->select_all_published_category();
                $data['recent_blog']=$this->welcome_model->select_recent_blog();
                $data['all_published_blog']=$this->welcome_model->select_all_published_blog();
                
                $data['maincontent']=$this->load->view('home_content',$data,true);
                $data['title']='Home';
                $data['slider']=1;
                $data['sidebarup']=1;
                $data['sidebardown']='';
		$this->load->view('master',$data);
	}
        
        public function support()
	{       $data=array();
                $data['all_published_category']=$this->welcome_model->select_all_published_category();
                $data['maincontent']=$this->load->view('support_content','',true);
                $data['title']='Support';
                $data['slider']='';
                $data['sidebarup']=1;
                $data['sidebardown']='';
		$this->load->view('master',$data);
	}
        public function about()
	{       $data=array();
                $data['all_published_category']=$this->welcome_model->select_all_published_category();
                $data['maincontent']=$this->load->view('about_content','',true);
                $data['title']='About_us';
                $data['slider']='';
                $data['sidebarup']='';
                $data['sidebardown']=1;
		$this->load->view('master',$data);
	}
        public function blog()
	{       $data=array();
                $data['all_published_category']=$this->welcome_model->select_all_published_category();
                $data['maincontent']=$this->load->view('blog_content','',true);
                $data['title']='Blog';
                $data['slider']=1;
                $data['sidebarup']=1;
                $data['sidebardown']='';
		$this->load->view('master',$data);
	}
        public function contact()
	{       $data=array();
                $data['all_published_category']=$this->welcome_model->select_all_published_category();
                $data['maincontent']=$this->load->view('contact_content','',true);
                $data['title']='Contact_us';
                $data['slider']='';
                $data['sidebarup']='';
                $data['sidebardown']='';
		$this->load->view('master',$data);
	}
        
        
        public function blog_detals($blog_id)
        {
           $data=array();
           $data['all_published_category']=$this->welcome_model->select_all_published_category();
           $data['blog_info']=$this->welcome_model->select_blog_info_by_id($blog_id);
           $data['maincontent']=$this->load->view('blog_detals',$data,true);
            $data['title']='Home';
            $data['slider']=1;
            $data['sidebarup']=1;
            $data['sidebardown']=1;
            $this->load->view('master',$data);
        }
        public function category_blog($category_id)
        {
            $data=array();
            $data['all_published_category']=$this->welcome_model->select_all_published_category();
            $data['category_blog']=$this->welcome_model->select_blog_by_category_id($category_id);
            $data['maincontent']=$this->load->view('category_blog',$data,true);
            $data['title']='Home';
            $data['slider']=1;
            $data['sidebarup']=1;
            $data['sidebardown']=1;
            $this->load->view('master',$data);  
        }
        
        public function sign_up()
        {
                $data=array();
                $data['all_published_category']=$this->welcome_model->select_all_published_category();
                $data['maincontent']=$this->load->view('sign_up','',true);
                $data['title']='Sign Up';
                $data['slider']='';
                $data['sidebarup']=1;
                $data['sidebardown']='';
		$this->load->view('master',$data); 
        }
        
        public function save_user()
        {
            $data=array();
            $data['user_name']=$this->input->post('user_name',true);
            $data['email_address']=$this->input->post('email_address',true);
            $data['password']=md5($this->input->post('password',true));
            $this->welcome_model->save_user_info($data);
            $sdata=array();
            $sdata['exception']='Regestration success.You may login now !!';
            $this->session->set_userdata($sdata);
            redirect('welcome/sign_up');
        }
        public function login()
        {
                $data=array();
                $data['all_published_category']=$this->welcome_model->select_all_published_category();
                $data['maincontent']=$this->load->view('sign_in','',true);
                $data['title']='Login';
                $data['slider']='';
                $data['sidebarup']=1;
                $data['sidebardown']='';
		$this->load->view('master',$data);   
        }
        
        public function user_login_check()
        {
            $email_address=$this->input->post('email_address',true);
            $password=$this->input->post('password',true);
            $result=$this->welcome_model->user_login_check_info($email_address,$password);
            $sdata=array();
            if($result)
            {
               $sdata['user_name']=$result->user_name;
               $sdata['user_id']=$result->user_id;
               $this->session->set_userdata($sdata);
               redirect('welcome');
               
            }
          else 
              {
              $sdata['exception']='Your User Id/Password Invalid!!';
              $this->session->set_userdata($sdata);
               redirect('welcome/login');
          }
        }
        
        
        
        
        
        
}
