<?php
class Evedence extends CI_controller {
function __construct(){	
parent::__construct();
$this->load->helper('url');	
$this->load->helper('form');	
$this->load->library('form_validation');
$this->load->model('Evedence_model');	
}	
public function index (){
	$data2['data'] = $this->Evedence_model->show();
	$this->load->view('evedence_view',$data2);
}
public function delete_user (){
	
	$user = $this->input->get('id');
	$this->Evedence_model->delete_user($user);
	redirect('Evedence/index');
}		
public function insert (){
	$this->load->library('form_validation');
	$this->form_validation->set_error_delimiters('','</br>');
	$this->form_validation->set_rules('myname','Name','required|min_length[3]');
	$this->form_validation->set_rules('email','Email','required|valid_email');
	$this->form_validation->set_rules('phone','Phone','required|integer');
	
	if($this->form_validation->run() == false){	
	$this->load->view('evedence_insert');	
	}
	else{
		$data = array(
		'name' => $this->input->post('myname'),
		'email' => $this->input->post('email'),
		'phone' => $this->input->post('phone')		
		);
		
		$this->Evedence_model->insert($data);
		 redirect('Evedence/index');
	}
}	
	
}
?>