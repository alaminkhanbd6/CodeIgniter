<?php
//session_start();
class Super_Admin extends CI_Controller {
    
    
    public function __construct() {
        parent::__construct();
        $admin_id=$this->session->userdata('admin_id');
        if($admin_id == NULL)
        {
            redirect('admin','refresh');
        }
        
        //$this->load->model('super_admin_model','sa_model');
    }
    
    public function index(){
        $data['admin_maincontent'] = $this->load->view('admin/deshbord', '', true);
        $this->load->view('admin/admin_master', $data);
    }
    
    public function add_category(){
        $data=array();
        $data['admin_maincontent'] = $this->load->view('admin/add_category_form', '', true);
        $this->load->view('admin/admin_master', $data);
        
    }
    
//    public function manage_blog()
//    {
//        $this->load->view('admin/manage_blog');
//    }

    

    public function save_category(){
        $data=array();
        $data['category_name']=$this->input->post('category_name',true);
        $data['category_description']=$this->input->post('category_description',true);
        $data['category_status']=$this->input->post('category_status',true);
        $this->super_admin_model->save_category_info($data);
        $sdata=array();
        $sdata['message']='save category information successfully!';
        $this->session->set_userdata($sdata);
        
        
        
        redirect('super_admin/add_category');
    }

    public function manage_category()
    {
         $data=array();
         $data['all_category']=$this->super_admin_model->select_all_category();
        $data['admin_maincontent'] = $this->load->view('admin/manage_category', $data, true);
        $this->load->view('admin/admin_master', $data);
        
    }
    public function unpublished_category($category_id)
    {
        $this->super_admin_model->update_unpublished_category($category_id);
        redirect('super_admin/manage_category');
    }
    public function published_category($category_id)
    {
        $this->super_admin_model->update_published_category($category_id);
        redirect('super_admin/manage_category');
    }
    public function delete_category($category_id)
    {
        $this->super_admin_model->delete_category_info($category_id);
        redirect('super_admin/manage_category');
    }
    
    public function edit_category($category_id)
    {
        $data=array();
        $data['category_info']=$this->super_admin_model->select_category_info_by_id($category_id);
        $data['admin_maincontent'] = $this->load->view('admin/edit_category_form', $data, true);
        $this->load->view('admin/admin_master', $data);  
    }
    
     public function update_category()
     {
        $data=array();
        $category_id=$this->input->post('category_id',true);
        $data['category_name']=$this->input->post('category_name',true);
        $data['category_description']=$this->input->post('category_description',true);
        
        $data['category_status']=$this->input->post('category_status',true);
        $this->super_admin_model->update_category_info($data,$category_id);
        redirect('super_admin/manage_category');
        
     }  
     
     public function add_blog()
     {
        $data=array(); 
        $data['all_published_category']=$this->welcome_model->select_all_published_category();
        $data['admin_maincontent'] = $this->load->view('admin/add_blog_form',$data, true);
        $this->load->view('admin/admin_master', $data); 
     }
     public function save_blog()
     {
      $data=array();
      $data['blog_title']=$this->input->post('blog_title',true);
      $data['category_id']=$this->input->post('category_id',true);
      $data['blog_short_description']=$this->input->post('blog_short_description',true);
      $data['blog_long_description']=$this->input->post('blog_long_description',true);
      $data['author_name']=$this->session->userdata('admin_full_name');
      $data['category_status']=$this->input->post('category_status',true);
      $this->super_admin_model->save_blog_info($data);
       $sdata=array();
       $sdata['message']='save Blog information successfully!';
       $this->session->set_userdata($sdata);
       redirect('super_admin/add_blog');
     }

     public function logout(){
        $this->session->unset_userdata('admin_id');
        $this->session->unset_userdata('admin_full_name');
        $sdata=array();
        $sdata['message']='You are successfully Logout!!';
        $this->session->set_userdata($sdata);
        redirect('admin');
    }
}
