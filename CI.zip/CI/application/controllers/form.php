<?php
class Form extends CI_Controller{
function __construct(){
parent::__construct();
$this->load->helper('form');  
$this->load->library('form_validation');  
$this->load->helper('url');  
$this->load->model('Form_model');  
}

public function index(){
	redirect('form/insert');
}	


public function insert(){
	
	
	$this->form_validation->set_rules('myname', 'Name', 'required|min_length[5]|alpha' );	
	
	$this->form_validation->set_rules('email', 'Email', 'required|valid_email' );	
	
	$this->form_validation->set_rules('phone', 'Phone', 'required|integer' );
	
	if($this->form_validation->run() == false){	
		$this->load->view('form_insert');	
	}
	else{
		$data = array(
		'name' => $this->input->post('myname'),
		'email' => $this->input->post('email'),
		'phone' => $this->input->post('phone')		
		);
		
		$this->Form_model->insert($data);
		
         redirect('form/insert');
	}
}	


	
}

?>