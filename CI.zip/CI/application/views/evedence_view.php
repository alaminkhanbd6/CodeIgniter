<p>
<button><?php echo anchor('evedence/insert','insert')?></button>
</p>
<table border="1" >
<tr>
<th>ID</th>
<th>NAME</th>
<th>EMAIL</th>
<th>PHONE</th>
<th>Action</th>
</tr>
<?php
foreach($data->result() as $users){
	
	echo "<tr>
	<td>$users->id</td>
	<td>$users->name</td>
	<td>$users->email</td>
	<td>$users->phone</td>
	<td>";
	echo anchor("evedence/delete_user?id=$users->id","Delete");
	echo "</td>
	</tr>";
	
};

?>
</table>