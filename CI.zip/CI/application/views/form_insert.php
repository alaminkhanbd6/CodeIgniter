<?php
if(validation_errors()){
	echo validation_errors();
}


?>


<form action="#" method="POST">
<input type="text" name="myname" placeholder="Name"/></br>
<input type="text" name="email"placeholder="Email"/></br>
<input type="text" name="phone"placeholder="Phone"/></br>
<input type="submit" value="submit"/></br>
</form>