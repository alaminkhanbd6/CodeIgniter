
<form action="<?php echo base_url();?>super_admin/save_blog" method="post">
    <div class="form-group">
        <label for="exampleInputEmail1">Add Blog</label>
        
        <h3>
            <?php
            $msg=$this->session->userdata('message');
            if($msg){
                echo $msg;
                $this->session->unset_userdata('message');
            }
            
            
            ?>
        </h3>
        <input type="text" class="form-control" name="blog_title" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Blog title">
        
    </div>

<div class="form-group">
        <label for="exampleFormControlSelect1">Category Name</label>
        <select class="form-control" name="category_id" id="exampleFormControlSelect1">
            <option>Select category</option>
            <?php
            foreach ($all_published_category as $v_category)
            {          
            ?>
            <option value="<?php echo $v_category->category_id?>"><?php echo $v_category->category_name?></option>
            <?php }?>

        </select>
    </div>

    
    
    
    

    <div class="form-group">
        <label for="exampleFormControlTextarea1">Blog Short  Description</label>
        <textarea class="form-control" name="blog_short_description" id="exampleFormControlTextarea1" rows="3"></textarea>
    </div>
     <div class="form-group">
        <label for="exampleFormControlTextarea1">Blog long Description</label>
        <textarea class="form-control" name="blog_long_description" id="exampleFormControlTextarea1" rows="3"></textarea>
    </div>
    
    
    <div class="form-group">
        <label for="exampleFormControlSelect1">Publication status</label>
        <select class="form-control" name="category_status" id="exampleFormControlSelect1">
            <option>Select status</option>
            <option value="1">Published</option>
            <option value="0">Unpublished</option>

        </select>
    </div>
    <button type="submit" name="submit" class="btn btn-primary">Submit</button>
</form>