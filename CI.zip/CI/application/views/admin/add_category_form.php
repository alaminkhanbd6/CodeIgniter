
<form action="<?php echo base_url();?>super_admin/save_category" method="post">
    <div class="form-group">
        <label for="exampleInputEmail1">Add Category</label>
        
        <h3>
            <?php
            $msg=$this->session->userdata('message');
            if($msg){
                echo $msg;
                $this->session->unset_userdata('message');
            }
            
            
            ?>
        </h3>
        <input type="text" class="form-control" name="category_name" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Add Category">
        
    </div>




    <div class="form-group">
        <label for="exampleFormControlTextarea1">Category Description</label>
        <textarea class="form-control" name="category_description" id="exampleFormControlTextarea1" rows="3"></textarea>
    </div>
    
    
    <div class="form-group">
        <label for="exampleFormControlSelect1">Publication status</label>
        <select class="form-control" name="category_status" id="exampleFormControlSelect1">
            <option>Select status</option>
            <option value="1">Published</option>
            <option value="0">Unpublished</option>

        </select>
    </div>
    <button type="submit" name="submit" class="btn btn-primary">Submit</button>
</form>