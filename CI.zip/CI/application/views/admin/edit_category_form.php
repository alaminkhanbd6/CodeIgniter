
<form name="edit_category_form" action="<?php echo base_url();?>super_admin/update_category" method="post">
    <div class="form-group">
        <label for="exampleInputEmail1">Edit Category</label>
        
        <h3>
            <?php
            $msg=$this->session->userdata('message');
            if($msg){
                echo $msg;
                $this->session->unset_userdata('message');
            }
            
            
            ?>
        </h3>
        <input type="text" value="<?php echo $category_info->category_name ?>" class="form-control" name="category_name" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Add Category">
        <input type="hidden" value="<?php echo $category_info->category_id ?>" class="form-control" name="category_id" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Add Category">
    </div>




    <div class="form-group">
        <label for="exampleFormControlTextarea1">Category Description</label>
        <textarea class="form-control" name="category_description" id="exampleFormControlTextarea1" rows="3"><?php echo $category_info->category_description ?></textarea>
    </div>
    
    
    <div class="form-group">
        <label for="exampleFormControlSelect1">Publication status</label>
        <select class="form-control" name="category_status" id="exampleFormControlSelect1">
            <option>Select status</option>
            <option value="1">Published</option>
            <option value="0">Unpublished</option>

        </select>
    </div>
    <button type="submit" name="submit" class="btn btn-primary">UPDATE</button>
</form>
<script type="text/javascript">
    document.forms['edit_category_form'].elements['category_status'].value='<?php echo $category_info->category_status ?>';
</script>