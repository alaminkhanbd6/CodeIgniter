<div class="article">
    <h2>Sign in using your account</h2>
    <h3 style="color: red">
        <?php
        $exc=$this->session->userdata('exception');
        if($exc)
        {
            echo $exc;
            $this->session->unset_userdata('exception');
        }
        ?>
    </h3>
</div>

<div class="article">
    
    <div class="clr"></div>
    <form action="<?php echo base_url();?>welcome/user_login_check" method="post" id="leavereply">
        <ol>
          
            <li>
                <label for="email">Email Address (required)</label>
                <input id="email" name="email_address" class="text" />
            </li>
            <li>
                <label for="password">Password</label>
                <input id="password" name="password" type="password" class="text" />
            </li>
           
            <li>
                <input type="submit" name="submit" id="submit" value="Sign in" class="send" />
                <div class="clr"></div>
            </li>
        </ol>
    </form>
</div>