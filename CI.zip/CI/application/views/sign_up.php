<div class="article">
    <h2>Sign Up Now</h2>
    <h3 style="color: green">
        <?php
        $exc=$this->session->userdata('exception');
        if($exc)
        {
            echo $exc;
            $this->session->unset_userdata('exception');
        }
        ?>
    </h3>
</div>

<div class="article">
    <h2>provide your information</h2>
    <div class="clr"></div>
    <form action="<?php echo base_url();?>welcome/save_user" method="post" id="leavereply">
        <ol>
            <li>
                <label for="name">Name (required)</label>
                <input id="name" name="user_name" class="text" />
            </li>
            <li>
                <label for="email">Email Address (required)</label>
                <input id="email" name="email_address" class="text" />
            </li>
            <li>
                <label for="password">Password</label>
                <input id="password" name="password" type="password" class="text" />
            </li>
           
            <li>
                <input type="submit" name="submit" id="submit" value="Regester" class="send" />
                <div class="clr"></div>
            </li>
        </ol>
    </form>
</div>